//
//  SwiftUIFurnitureStoreApp.swift
//  SwiftUIFurnitureStore
//
//  Created by Levon Shaxbazyan on 06.05.24.
//

import SwiftUI

@main
struct SwiftUIFurnitureStoreApp: App {
    var body: some Scene {
        WindowGroup {
            StartPageView()
        }
    }
}
