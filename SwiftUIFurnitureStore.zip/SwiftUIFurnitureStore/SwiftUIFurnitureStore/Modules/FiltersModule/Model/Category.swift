//
//  Category.swift
//  SwiftUIFurnitureStore
//
//  Created by Levon Shaxbazyan on 09.05.24.
//

import Foundation

/// Оформление категорий мебели
struct Category {
    // картинка категории мебеля
    let image: String
}
