//
//  BasketView.swift
//  SwiftUIFurnitureStore
//
//  Created by Levon Shaxbazyan on 10.05.24.
//

import SwiftUI

struct BasketView: View {
    var body: some View {
        ZStack {
            Color(.blue)
        }
    }
}
